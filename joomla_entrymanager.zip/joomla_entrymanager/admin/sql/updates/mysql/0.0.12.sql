-- $Id: install.mysql.utf8.sql 50 2010-11-21 20:47:46Z chdemko $

ALTER TABLE `#__entrymanager` ADD `catid` int(11) NOT NULL DEFAULT '0';

