-- $Id: uninstall.mysql.utf8.sql 74 2010-12-01 22:04:52Z chdemko $

DROP TABLE IF EXISTS `#__entrymanager`;

